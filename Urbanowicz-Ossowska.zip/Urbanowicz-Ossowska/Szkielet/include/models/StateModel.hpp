#ifndef STATEMODEL_HPP
#define STATEMODEL_HPP

class StateModel {
    
    public:
        virtual void update() = 0;
};

#endif 