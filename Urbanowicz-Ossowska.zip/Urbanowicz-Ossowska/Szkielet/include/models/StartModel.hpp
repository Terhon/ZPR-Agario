#ifndef STARTMODEL_HPP
#define STARTMODEL_HPP

#include <StateModel.hpp>

class StartModel : public StateModel {
    
    public:
        virtual void update();
};

#endif