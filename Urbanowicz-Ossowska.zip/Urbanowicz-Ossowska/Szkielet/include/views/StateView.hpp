#ifndef STATEVIEW_HPP
#define STATEVIEW_HPP

class StateView {
    
    public:
        virtual void draw() = 0;
};

#endif STATEVIEW_HPP