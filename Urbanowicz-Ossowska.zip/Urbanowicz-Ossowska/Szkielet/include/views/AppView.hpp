#ifndef APPVIEW_H
#define APPVIEW_H

class AppView
{
    private:

    public:
    AppView(){}

    void draw(){}
};

#endif