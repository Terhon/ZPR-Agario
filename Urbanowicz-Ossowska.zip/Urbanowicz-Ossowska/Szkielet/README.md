# Zjadające się kulki - gra w C++

**install-agario.sh** instaluje biblioteki SFML i Boost oraz cmake'a i buduje aplikację i testy
**build.sh** tylko buduje aplikację i testy
**test-agario** uruchamia testy
Zbudowana aplikacja znajduje się w katalogu build, testy - w testBin. 