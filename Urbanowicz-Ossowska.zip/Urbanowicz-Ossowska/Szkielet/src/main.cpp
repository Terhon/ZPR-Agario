#include <iostream>
#include <App.hpp>

int main(int argc, char const *argv[])
{
    App app;
    app.run();
    return 0;
}
