#include <StartModel.hpp>

void StartModel::update(){
    
}